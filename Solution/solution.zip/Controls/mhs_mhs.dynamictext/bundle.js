/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./dynamictext/index.ts":
/*!******************************!*\
  !*** ./dynamictext/index.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.dynamictext = void 0;\nvar dynamictext = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function dynamictext() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  dynamictext.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._context = context;\n    this._controlViewRendered = false;\n    this._container = document.createElement(\"div\");\n    this._container.classList.add(\"WebAPIControl_Container\");\n    container.appendChild(this._container);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  dynamictext.prototype.updateView = function (context) {\n    var _this = this;\n    // Add code to update control view\n    this._resultContainerDiv = this.createHTMLDivElement(\"result_container\", false, undefined);\n    this._container.appendChild(this._resultContainerDiv);\n    var queryString = \"\";\n    var multilinetext = context.parameters.MultilineText.raw == null ? \"\" : context.parameters.MultilineText.raw;\n    var entityname = context.parameters.entityname.raw == null ? \"\" : context.parameters.entityname.raw;\n    var requiredAttributeKey = context.parameters.requiredAttributeKey.raw == null ? \"\" : context.parameters.requiredAttributeKey.raw;\n    var requiredAttributeValue = context.parameters.requiredAttributeValue.raw == null ? \"\" : context.parameters.requiredAttributeValue.raw;\n    if (entityname != \"\" && requiredAttributeKey != \"\" && requiredAttributeValue != \"\" && context.parameters.Lookup.raw[0] != null) {\n      var lookupValue = context.parameters.Lookup.raw[0];\n      queryString = \"?$select=\".concat(requiredAttributeValue, \"&$filter=contains(\").concat(requiredAttributeKey, \",'\").concat(lookupValue.name, \"')\");\n      var returntext_1 = \"\";\n      context.webAPI.retrieveMultipleRecords(entityname, queryString).then(function (response) {\n        for (var _i = 0, _a = response.entities; _i < _a.length; _i++) {\n          var entity = _a[_i];\n          // Retrieve the value of _currencyAttributeName field\n          returntext_1 = entity[requiredAttributeValue];\n          _this.updateResultContainerText(returntext_1);\n          _this._container.appendChild(_this._resultContainerDiv);\n        }\n      });\n    } else {\n      this.updateResultContainerText(multilinetext);\n      this._container.appendChild(this._resultContainerDiv);\n    }\n  };\n  dynamictext.prototype.createHTMLDivElement = function (elementClassName, isHeader, innerText) {\n    var div = document.createElement(\"div\");\n    if (isHeader) {\n      div.classList.add(\"SampleControl_WebAPIControl_Header\");\n      elementClassName += \"_header\";\n    }\n    if (innerText) {\n      div.innerText = innerText.toUpperCase();\n    }\n    div.classList.add(elementClassName);\n    return div;\n  };\n  dynamictext.prototype.updateResultContainerText = function (statusHTML) {\n    if (this._resultContainerDiv) {\n      this._resultContainerDiv.innerHTML = statusHTML;\n    }\n  };\n  dynamictext.prototype.updateResultContainerTextWithErrorResponse = function (errorResponse) {\n    if (this._resultContainerDiv) {\n      // Retrieve the error message from the errorResponse and inject into the result div\n      var errorHTML = \"Error with Web API call:\";\n      errorHTML += \"<br />\";\n      errorHTML += errorResponse.message;\n      this._resultContainerDiv.innerHTML = errorHTML;\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  dynamictext.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  dynamictext.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return dynamictext;\n}();\nexports.dynamictext = dynamictext;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./dynamictext/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./dynamictext/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('mhs.dynamictext', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.dynamictext);
} else {
	var mhs = mhs || {};
	mhs.dynamictext = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.dynamictext;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}